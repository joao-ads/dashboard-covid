export * from './dashboard-covid.module';
export * from './dashboard-covid.component';
export * from './dados.service';
export * from './model'

