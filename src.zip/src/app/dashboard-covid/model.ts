export class MonthlyCases {
  public month: string
  public cases: number

  constructor(month: string, cases: number) {
    this.month = month;
    this.cases = cases;
  }

}